# MedSpacy1 - Medical Report Analysis

Experimental MedSpacy code for extracting and classifying medical conditions from clinical reports.

## Overview

This project uses [MedSpacy](https://github.com/medspacy/medspacy), a clinical Natural Language Processing (NLP) library, to analyze medical reports and extract medical conditions with sentiment classification. The system processes medical text from Findings and Conclusions sections and determines whether each condition is **true**, **false**, or **indeterminate**.

## What is MedSpacy?

MedSpacy is a specialized NLP library built on top of spaCy, designed specifically for clinical and biomedical text processing. It provides:

- **Clinical Entity Recognition**: Identifies medical conditions, symptoms, treatments, etc.
- **Context Detection**: Determines negation (e.g., "no fever"), uncertainty (e.g., "possible pneumonia"), and other linguistic modifiers
- **Section Detection**: Recognizes document structure in clinical reports
- **Attribute Extraction**: Identifies temporal information, severity, etc.

## Features

- ✅ Processes CSV files with medical reports
- ✅ Extracts medical conditions from Findings and Conclusions
- ✅ Classifies each condition as:
  - **true**: Condition is present/affirmed
  - **false**: Condition is explicitly negated
  - **indeterminate**: Condition is uncertain or hypothetical
- ✅ Provides detailed analysis with reasoning
- ✅ Generates structured output in CSV format
- ✅ Includes sample medical reports for testing

## Installation

### Prerequisites

- Python 3.8 or higher
- pip package manager

### Setup Instructions

1. **Clone the repository**:
   ```bash
   git clone https://github.com/Vet-Rocket/MedSpacy1.git
   cd MedSpacy1
   ```

2. **Install dependencies**:
   ```bash
   pip install -r requirements.txt
   ```

3. **Download the spaCy language model**:
   ```bash
   python -m spacy download en_core_web_sm
   ```

   *Note: This downloads a ~20MB English language model required for text processing*

## Usage

### Basic Usage

Run the analysis script with the sample data:

```bash
python analyze_medical_reports.py
```

This will:
- Process the `sample_medical_reports.csv` file
- Analyze 10 medical reports
- Generate `analysis_results.csv` with detailed results
- Print a summary to the console

### Custom Input/Output Files

Specify custom input and output files:

```bash
python analyze_medical_reports.py input.csv output.csv
```

### Input Format

The input CSV file must contain three columns:

| Column | Description |
|--------|-------------|
| RowID | Unique identifier for each report |
| Findings | Clinical findings and observations |
| Conclusions | Diagnostic conclusions and interpretations |

Example:
```csv
RowID,Findings,Conclusions
1,"Patient presents with fever and cough. Chest X-ray shows infiltrates.","Diagnosis: Pneumonia. Requires antibiotic therapy."
```

### Output Format

The output CSV includes:

- Original report data (RowID, Findings, Conclusions)
- `Conditions_Found`: Number of conditions identified
- `Conditions_List`: Human-readable summary of all conditions
- Individual condition details (name, sentiment, reasoning)

Example output:
```
RowID: 1
Conditions: pneumonia: true (affirmed) | pleural effusion: false (negated)
```

## Sample Data

The `sample_medical_reports.csv` file contains 10 realistic medical reports covering various conditions:

1. Community-acquired pneumonia
2. Normal abdominal CT
3. Congestive heart failure
4. Rule out myocardial infarction
5. Multiple sclerosis (suspected)
6. Deep vein thrombosis (ruled out)
7. Malignant melanoma
8. Mild anemia
9. Chronic obstructive pulmonary disease (COPD)
10. Suspicious breast mass

## How It Works

### Technical Architecture

```
Input CSV → MedSpacy Pipeline → Entity Extraction → Context Analysis → Classification → Output CSV
```

### Step-by-Step Process

1. **Text Loading**: Reads medical reports from CSV file
   - Validates required columns (RowID, Findings, Conclusions)
   - Handles missing or malformed data

2. **NLP Pipeline Processing**:
   - Tokenization: Breaks text into words and punctuation
   - Part-of-Speech Tagging: Identifies grammatical roles
   - Named Entity Recognition (NER): Identifies medical entities
   - Context Detection: Analyzes linguistic modifiers

3. **Entity Extraction**:
   - Identifies medical conditions, symptoms, and diagnoses
   - Captures entity text, type, and position in document

4. **Context Analysis**:
   - **Negation Detection**: Identifies phrases like "no", "without", "absent"
   - **Uncertainty Detection**: Identifies phrases like "possible", "likely", "suspicious"
   - **Hypothetical Detection**: Identifies conditional statements

5. **Sentiment Classification**:
   - **false**: Entity is negated (e.g., "no evidence of pneumonia")
   - **indeterminate**: Entity is uncertain (e.g., "possible pneumonia")
   - **true**: Entity is affirmed (e.g., "pneumonia present")

6. **Output Generation**:
   - Compiles results into structured format
   - Generates human-readable summaries
   - Saves to CSV for further analysis

### Classification Logic

```python
if negated:
    sentiment = 'false'      # Condition explicitly ruled out
elif uncertain or hypothetical:
    sentiment = 'indeterminate'  # Condition possible but not confirmed
else:
    sentiment = 'true'       # Condition present
```

## Code Structure

```
MedSpacy1/
├── analyze_medical_reports.py    # Main analysis script
├── sample_medical_reports.csv    # Sample input data
├── requirements.txt              # Python dependencies
└── README.md                     # This file
```

### Key Components

**`MedicalReportAnalyzer` Class**:
- `__init__()`: Initializes MedSpacy pipeline
- `extract_conditions()`: Extracts conditions from text with sentiment
- `analyze_report()`: Processes complete report (Findings + Conclusions)
- `process_csv()`: Batch processes CSV file
- `print_analysis_summary()`: Displays results

## Understanding the Output

### Sentiment Categories

| Sentiment | Meaning | Example Phrases |
|-----------|---------|-----------------|
| **true** | Condition is present | "shows pneumonia", "diagnosis: diabetes", "patient has hypertension" |
| **false** | Condition is absent | "no pneumonia", "rules out cancer", "without signs of infection" |
| **indeterminate** | Condition is uncertain | "possible pneumonia", "suspicious for cancer", "cannot exclude DVT" |

### Context Modifiers

MedSpacy detects various linguistic patterns:

- **Negation**: no, without, absent, denies, negative for, free of
- **Uncertainty**: possible, likely, suspicious, cannot exclude, rule out
- **Hypothetical**: if, should, would, could indicate
- **Historical**: history of, previous, prior

## Recommendations for Future Refinements

### 1. **Enhanced Entity Recognition**
   - Train custom entity recognizer on domain-specific data
   - Add recognition for:
     - Medications and dosages
     - Laboratory values and reference ranges
     - Anatomical locations
     - Procedure names

### 2. **Temporal Analysis**
   - Extract temporal information (when conditions occurred)
   - Distinguish between:
     - Current conditions
     - Historical conditions
     - Future/planned interventions

### 3. **Severity Classification**
   - Add severity levels (mild, moderate, severe)
   - Extract quantitative measures
   - Identify critical vs. routine findings

### 4. **Relationship Extraction**
   - Link conditions to causes
   - Identify condition-treatment pairs
   - Map diagnostic reasoning chains

### 5. **Section Awareness**
   - Use MedSpacy's Sectionizer component
   - Provide context based on document sections
   - Different processing for different section types

### 6. **Assertion Classification**
   - Expand beyond true/false/indeterminate:
     - Associated with other person
     - Conditional
     - Generic statement

### 7. **Integration Enhancements**
   - RESTful API for real-time analysis
   - Batch processing optimization for large datasets
   - Integration with EHR systems
   - Support for additional file formats (JSON, XML, HL7)

### 8. **Quality Metrics**
   - Add confidence scores for each classification
   - Implement human-in-the-loop validation
   - Track inter-annotator agreement

### 9. **Visualization**
   - Generate visual reports with condition summaries
   - Create timeline visualizations
   - Highlight critical findings

### 10. **Model Improvements**
   - Fine-tune on institution-specific data
   - Use larger language models (en_core_web_md, en_core_web_lg)
   - Incorporate domain-specific terminology

### 11. **Error Handling**
   - Robust handling of malformed input
   - Graceful degradation for incomplete data
   - Detailed logging for debugging

### 12. **Performance Optimization**
   - Parallel processing for large datasets
   - Caching for repeated analyses
   - GPU acceleration for deep learning components

## Troubleshooting

### Common Issues

**Issue**: `OSError: [E050] Can't find model 'en_core_web_sm'`
**Solution**: Run `python -m spacy download en_core_web_sm`

**Issue**: Import errors with medspacy
**Solution**: Reinstall with `pip install --upgrade medspacy spacy`

**Issue**: No conditions detected
**Solution**: Check input text format and ensure medical terminology is present

**Issue**: Poor accuracy on domain-specific terminology
**Solution**: Consider using a larger model or training custom entity recognizer

## Contributing

Contributions are welcome! Areas for improvement:
- Additional sample reports
- Enhanced entity recognition
- Better context detection
- Performance optimizations

## License

This is experimental research code. Please check with the repository owner for licensing terms.

## References

- [MedSpacy Documentation](https://medspacy.github.io/medspacy/)
- [spaCy Documentation](https://spacy.io/)
- [Clinical NLP with spaCy](https://allenai.github.io/scispacy/)

## Contact

For questions or issues, please open an issue on the GitHub repository.
