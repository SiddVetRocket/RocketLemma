"""
Medical Report Analysis using MedSpacy

This script processes medical reports (Findings and Conclusions) from a CSV file
and extracts medical conditions with their sentiment classification.

Purpose:
    - Extract medical conditions from clinical text
    - Classify each condition as: true, false, or indeterminate
    - Use MedSpacy's context detection for negation and uncertainty

Author: MedSpacy1 Project
Date: 2025-10-14
"""

import sys
import pandas as pd
import spacy
import medspacy
from typing import List, Dict, Tuple
from pathlib import Path


class MedicalReportAnalyzer:
    """
    Analyzes medical reports to extract and classify medical conditions.
    
    This class uses MedSpacy, a specialized clinical NLP library built on spaCy,
    to process medical text and identify conditions with their associated context
    (negation, uncertainty, etc.).
    """
    
    def __init__(self, model_name: str = "en_core_web_sm"):
        """
        Initialize the Medical Report Analyzer with MedSpacy pipeline.
        
        Args:
            model_name: Name of the spaCy language model to use
            
        The initialization process:
        1. Loads the specified spaCy language model
        2. Adds MedSpacy components to the pipeline
        3. Configures entity recognition and context detection
        4. Adds custom medical entity patterns
        
        MedSpacy Components Added:
        - Target Matcher: Identifies clinical entities (diseases, symptoms)
        - Context: Detects negation, uncertainty, and other linguistic modifiers
        - Sectionizer: Identifies document sections (optional, for structured reports)
        """
        print(f"Initializing MedSpacy with model: {model_name}")
        
        # Load MedSpacy with the specified model
        # MedSpacy extends spaCy with medical-specific functionality
        # We disable the parser to avoid conflicts with PyRuSH sentencizer
        try:
            self.nlp = medspacy.load(model_name, disable=["parser"])
        except OSError:
            print(f"Model '{model_name}' not found. Please install it:")
            print(f"python -m spacy download {model_name}")
            sys.exit(1)
        
        # Add custom medical condition patterns to the target matcher
        # This allows us to identify specific medical conditions in the text
        self._add_medical_patterns()
        
        print("MedSpacy pipeline initialized successfully")
        print(f"Pipeline components: {self.nlp.pipe_names}")
    
    def _add_medical_patterns(self):
        """
        Add custom medical entity patterns to the target matcher.
        
        This method defines patterns for common medical conditions that should
        be identified in clinical text. The patterns use MedSpacy's TargetRule
        to specify both the condition name and matching patterns.
        
        Pattern Types:
        - Literal: Exact text match (case-insensitive)
        - Pattern: Token-level pattern matching (using spaCy's pattern syntax)
        
        Categories covered:
        - Respiratory conditions
        - Cardiac conditions
        - Neurological conditions
        - Vascular conditions
        - Oncological conditions
        - Hematological conditions
        - General pathology
        """
        from medspacy.ner import TargetRule
        
        # Get the target matcher component from the pipeline
        target_matcher = self.nlp.get_pipe("medspacy_target_matcher")
        
        # Define comprehensive medical condition patterns
        # Each TargetRule specifies a condition and how to match it in text
        medical_patterns = [
            # Respiratory Conditions
            TargetRule("pneumonia", "CONDITION"),
            TargetRule("pleural effusion", "CONDITION"),
            TargetRule("shortness of breath", "SYMPTOM"),
            TargetRule("dyspnea", "SYMPTOM"),
            TargetRule("cough", "SYMPTOM"),
            TargetRule("infiltrates", "FINDING"),
            TargetRule("COPD", "CONDITION"),
            TargetRule("chronic obstructive pulmonary disease", "CONDITION"),
            TargetRule("obstructive pattern", "FINDING"),
            
            # Cardiac Conditions
            TargetRule("myocardial infarction", "CONDITION"),
            TargetRule("congestive heart failure", "CONDITION"),
            TargetRule("heart failure", "CONDITION"),
            TargetRule("mitral regurgitation", "CONDITION"),
            TargetRule("chest pain", "SYMPTOM"),
            TargetRule("atrial enlargement", "FINDING"),
            
            # Neurological Conditions
            TargetRule("multiple sclerosis", "CONDITION"),
            TargetRule("demyelinating disease", "CONDITION"),
            TargetRule("lesions", "FINDING"),
            
            # Vascular Conditions
            TargetRule("deep vein thrombosis", "CONDITION"),
            TargetRule("DVT", "CONDITION"),
            TargetRule("thrombophlebitis", "CONDITION"),
            
            # Oncological Conditions
            TargetRule("melanoma", "CONDITION"),
            TargetRule("malignant melanoma", "CONDITION"),
            TargetRule("breast cancer", "CONDITION"),
            TargetRule("cancer", "CONDITION"),
            TargetRule("malignancy", "CONDITION"),
            TargetRule("mass", "FINDING"),
            TargetRule("leukemia", "CONDITION"),
            TargetRule("lymphoma", "CONDITION"),
            
            # Hematological Conditions
            TargetRule("anemia", "CONDITION"),
            
            # General Pathology
            TargetRule("fever", "SYMPTOM"),
            TargetRule("pathology", "FINDING"),
            TargetRule("acute findings", "FINDING"),
            TargetRule("normal", "FINDING"),
        ]
        
        # Add all patterns to the target matcher
        target_matcher.add(medical_patterns)
        
        print(f"Added {len(medical_patterns)} custom medical condition patterns")
    
    def extract_conditions(self, text: str) -> List[Dict[str, any]]:
        """
        Extract medical conditions from text with sentiment classification.
        
        Args:
            text: Medical text to analyze (Findings or Conclusions)
            
        Returns:
            List of dictionaries containing:
            - condition: The medical condition text
            - sentiment: Classification as 'true', 'false', or 'indeterminate'
            - context: Additional context information
            
        Processing Steps:
        1. Process text through MedSpacy NLP pipeline
        2. Extract entities identified as medical conditions
        3. Analyze context (negation, uncertainty, hypothetical)
        4. Classify sentiment based on context attributes
        
        Sentiment Classification Logic:
        - 'false': Condition is explicitly negated (e.g., "no pneumonia")
        - 'indeterminate': Condition is uncertain/hypothetical (e.g., "possible pneumonia")
        - 'true': Condition is affirmed (e.g., "pneumonia present")
        """
        if not text or pd.isna(text):
            return []
        
        # Process the text through the MedSpacy pipeline
        # This performs tokenization, entity recognition, and context detection
        doc = self.nlp(text)
        
        conditions = []
        
        # Iterate through all entities found by the NER component
        # MedSpacy identifies medical entities using both rule-based and ML approaches
        for ent in doc.ents:
            # Create a condition record with full context information
            condition_info = {
                'condition': ent.text,
                'label': ent.label_,  # Entity type (e.g., PROBLEM, TREATMENT)
                'start': ent.start_char,
                'end': ent.end_char
            }
            
            # Analyze context using MedSpacy's context component
            # The context component detects linguistic modifiers around entities
            if hasattr(ent._, 'is_negated'):
                is_negated = ent._.is_negated
            else:
                is_negated = False
            
            if hasattr(ent._, 'is_uncertain'):
                is_uncertain = ent._.is_uncertain
            else:
                is_uncertain = False
            
            if hasattr(ent._, 'is_hypothetical'):
                is_hypothetical = ent._.is_hypothetical
            else:
                is_hypothetical = False
            
            # Classify sentiment based on context attributes
            # Priority: Negation > Uncertainty > Affirmative
            if is_negated:
                sentiment = 'false'
                reason = 'negated'
            elif is_uncertain or is_hypothetical:
                sentiment = 'indeterminate'
                reason = 'uncertain' if is_uncertain else 'hypothetical'
            else:
                sentiment = 'true'
                reason = 'affirmed'
            
            condition_info['sentiment'] = sentiment
            condition_info['reason'] = reason
            condition_info['is_negated'] = is_negated
            condition_info['is_uncertain'] = is_uncertain
            condition_info['is_hypothetical'] = is_hypothetical
            
            conditions.append(condition_info)
        
        return conditions
    
    def analyze_report(self, row_id: str, findings: str, conclusions: str) -> Dict:
        """
        Analyze a complete medical report (Findings + Conclusions).
        
        Args:
            row_id: Unique identifier for the report
            findings: Clinical findings section
            conclusions: Clinical conclusions section
            
        Returns:
            Dictionary containing analysis results for the entire report
            
        Processing Approach:
        1. Process Findings and Conclusions separately
        2. Extract conditions from each section
        3. Combine results with section attribution
        4. Generate summary statistics
        
        Why process sections separately?
        - Findings often contain observational data
        - Conclusions contain diagnostic interpretations
        - Separating them helps track information flow
        """
        print(f"\nAnalyzing Report ID: {row_id}")
        
        # Extract conditions from Findings section
        findings_conditions = self.extract_conditions(findings)
        print(f"  Found {len(findings_conditions)} conditions in Findings")
        
        # Extract conditions from Conclusions section
        conclusions_conditions = self.extract_conditions(conclusions)
        print(f"  Found {len(conclusions_conditions)} conditions in Conclusions")
        
        # Compile comprehensive report analysis
        report_analysis = {
            'row_id': row_id,
            'findings_text': findings,
            'conclusions_text': conclusions,
            'findings_conditions': findings_conditions,
            'conclusions_conditions': conclusions_conditions,
            'total_conditions': len(findings_conditions) + len(conclusions_conditions)
        }
        
        return report_analysis
    
    def format_condition_output(self, condition: Dict) -> str:
        """
        Format a condition for display output.
        
        Args:
            condition: Dictionary containing condition information
            
        Returns:
            Formatted string: "condition_name: sentiment (reason)"
            
        This provides human-readable output following the specification:
        "condition: true | false | indeterminate"
        """
        return f"{condition['condition']}: {condition['sentiment']} ({condition['reason']})"
    
    def process_csv(self, csv_path: str, output_path: str = None) -> pd.DataFrame:
        """
        Process a CSV file containing medical reports.
        
        Args:
            csv_path: Path to input CSV file (must have columns: RowID, Findings, Conclusions)
            output_path: Optional path for output CSV file with analysis results
            
        Returns:
            DataFrame containing original data plus analysis results
            
        CSV Processing Flow:
        1. Load CSV file using pandas
        2. Validate required columns exist
        3. Iterate through each report row
        4. Apply NLP analysis to each report
        5. Compile results into structured format
        6. Optionally save results to output file
        
        Output Format:
        - Preserves original columns
        - Adds analysis columns for conditions found
        - Creates human-readable condition summaries
        """
        print(f"Loading medical reports from: {csv_path}")
        
        # Load CSV file
        try:
            df = pd.read_csv(csv_path)
        except FileNotFoundError:
            print(f"Error: File not found: {csv_path}")
            sys.exit(1)
        except Exception as e:
            print(f"Error reading CSV file: {e}")
            sys.exit(1)
        
        # Validate required columns
        required_columns = ['RowID', 'Findings', 'Conclusions']
        missing_columns = [col for col in required_columns if col not in df.columns]
        if missing_columns:
            print(f"Error: CSV missing required columns: {missing_columns}")
            print(f"Available columns: {df.columns.tolist()}")
            sys.exit(1)
        
        print(f"Successfully loaded {len(df)} reports")
        
        # Process each report
        results = []
        for idx, row in df.iterrows():
            analysis = self.analyze_report(
                row_id=str(row['RowID']),
                findings=row['Findings'],
                conclusions=row['Conclusions']
            )
            results.append(analysis)
        
        # Create output DataFrame with detailed results
        output_rows = []
        for result in results:
            # Combine all conditions from both sections
            all_conditions = (
                result['findings_conditions'] + 
                result['conclusions_conditions']
            )
            
            # Create formatted condition strings
            condition_strings = [
                self.format_condition_output(cond) for cond in all_conditions
            ]
            
            # Build output row
            output_row = {
                'RowID': result['row_id'],
                'Findings': result['findings_text'],
                'Conclusions': result['conclusions_text'],
                'Conditions_Found': len(all_conditions),
                'Conditions_List': ' | '.join(condition_strings) if condition_strings else 'No conditions identified'
            }
            
            # Add individual condition details
            for i, cond in enumerate(all_conditions, 1):
                output_row[f'Condition_{i}'] = cond['condition']
                output_row[f'Condition_{i}_Sentiment'] = cond['sentiment']
                output_row[f'Condition_{i}_Reason'] = cond['reason']
            
            output_rows.append(output_row)
        
        # Create output DataFrame
        output_df = pd.DataFrame(output_rows)
        
        # Save results if output path provided
        if output_path:
            output_df.to_csv(output_path, index=False)
            print(f"\nResults saved to: {output_path}")
        
        return output_df
    
    def print_analysis_summary(self, results_df: pd.DataFrame):
        """
        Print a summary of the analysis results.
        
        Args:
            results_df: DataFrame containing analysis results
            
        This provides an overview of:
        - Total reports processed
        - Total conditions identified
        - Distribution of sentiments
        - Sample conditions from each category
        """
        print("\n" + "="*80)
        print("ANALYSIS SUMMARY")
        print("="*80)
        
        print(f"\nTotal Reports Analyzed: {len(results_df)}")
        print(f"Total Conditions Found: {results_df['Conditions_Found'].sum()}")
        print(f"Average Conditions per Report: {results_df['Conditions_Found'].mean():.2f}")
        
        print("\n" + "-"*80)
        print("DETAILED RESULTS BY REPORT")
        print("-"*80)
        
        for idx, row in results_df.iterrows():
            print(f"\nReport {row['RowID']}:")
            print(f"  Conditions: {row['Conditions_List']}")


def main():
    """
    Main entry point for the medical report analysis script.
    
    Usage:
        python analyze_medical_reports.py [input_csv] [output_csv]
        
    Arguments:
        input_csv: Path to input CSV file (default: sample_medical_reports.csv)
        output_csv: Path to output CSV file (default: analysis_results.csv)
        
    Workflow:
    1. Parse command line arguments
    2. Initialize MedSpacy analyzer
    3. Process input CSV file
    4. Generate analysis results
    5. Print summary and save output
    """
    # Parse command line arguments
    if len(sys.argv) > 1:
        input_csv = sys.argv[1]
    else:
        input_csv = "sample_medical_reports.csv"
    
    if len(sys.argv) > 2:
        output_csv = sys.argv[2]
    else:
        output_csv = "analysis_results.csv"
    
    print("="*80)
    print("MEDICAL REPORT ANALYSIS USING MEDSPACY")
    print("="*80)
    print(f"\nInput file: {input_csv}")
    print(f"Output file: {output_csv}")
    
    # Initialize analyzer
    analyzer = MedicalReportAnalyzer()
    
    # Process reports
    results = analyzer.process_csv(input_csv, output_csv)
    
    # Print summary
    analyzer.print_analysis_summary(results)
    
    print("\n" + "="*80)
    print("ANALYSIS COMPLETE")
    print("="*80)


if __name__ == "__main__":
    main()
