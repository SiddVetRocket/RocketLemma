# Future Refinements and Recommendations

This document outlines potential improvements and enhancements for the MedSpacy Medical Report Analysis system.

## Table of Contents
1. [Immediate Improvements](#immediate-improvements)
2. [Enhanced Entity Recognition](#enhanced-entity-recognition)
3. [Advanced Context Analysis](#advanced-context-analysis)
4. [Performance Optimizations](#performance-optimizations)
5. [Integration and Deployment](#integration-and-deployment)
6. [Quality Assurance](#quality-assurance)

---

## Immediate Improvements

### 1. Confidence Scoring
**Problem**: Current system provides binary classifications without confidence levels.

**Solution**: Add confidence scores to each classification.

```python
def extract_conditions_with_confidence(self, text: str):
    """Extract conditions with confidence scores."""
    doc = self.nlp(text)
    
    for ent in doc.ents:
        # Calculate confidence based on multiple factors
        confidence = self._calculate_confidence(ent, doc)
        
        condition_info = {
            'condition': ent.text,
            'sentiment': self._classify_sentiment(ent),
            'confidence': confidence,  # 0.0 to 1.0
            'confidence_factors': {
                'context_clarity': 0.9,
                'entity_boundary': 0.8,
                'negation_distance': 1.0
            }
        }
```

**Benefits**:
- Allows filtering low-confidence results
- Enables human review prioritization
- Improves clinical decision support

---

### 2. Duplicate Detection
**Problem**: Same condition may be mentioned multiple times (e.g., "pneumonia" in both Findings and Conclusions).

**Solution**: Implement entity resolution and deduplication.

```python
def deduplicate_conditions(self, findings_conditions, conclusions_conditions):
    """Remove duplicate conditions while preserving most confident classification."""
    seen = {}
    for cond in findings_conditions + conclusions_conditions:
        key = cond['condition'].lower()
        if key not in seen or cond.get('confidence', 0) > seen[key].get('confidence', 0):
            seen[key] = cond
    return list(seen.values())
```

---

### 3. Structured Output Format
**Problem**: Current output is flat CSV, difficult to use programmatically.

**Solution**: Add JSON output option with hierarchical structure.

```json
{
  "report_id": "1",
  "metadata": {
    "analysis_date": "2025-10-14",
    "analyzer_version": "1.0",
    "model": "en_core_web_sm"
  },
  "findings": {
    "text": "Patient presents with fever...",
    "conditions": [
      {
        "name": "fever",
        "sentiment": "true",
        "confidence": 0.95,
        "span": [21, 26],
        "context": "affirmed"
      }
    ]
  },
  "conclusions": {
    "text": "Diagnosis: pneumonia...",
    "conditions": [...]
  },
  "summary": {
    "total_conditions": 7,
    "affirmed": 5,
    "negated": 1,
    "uncertain": 1
  }
}
```

---

## Enhanced Entity Recognition

### 1. Medical Terminology Expansion
**Current State**: 34 condition patterns defined.

**Recommendation**: Expand to comprehensive medical ontology.

**Implementation Options**:

#### Option A: UMLS Integration
```python
from medspacy.ner import TargetRule
from umls_client import UMLSClient

def load_umls_concepts(self, semantic_types=['T047', 'T048', 'T184']):
    """Load concepts from UMLS by semantic type.
    
    T047: Disease or Syndrome
    T048: Mental or Behavioral Dysfunction
    T184: Sign or Symptom
    """
    client = UMLSClient(api_key='your_key')
    concepts = client.get_concepts(semantic_types)
    
    rules = []
    for concept in concepts:
        rules.append(TargetRule(
            literal=concept['preferred_name'],
            category="CONDITION",
            metadata={'cui': concept['cui']}
        ))
    
    return rules
```

#### Option B: Custom Medical Dictionary
```python
# Define comprehensive condition categories
CONDITIONS = {
    'respiratory': [
        'pneumonia', 'bronchitis', 'asthma', 'COPD', 
        'tuberculosis', 'emphysema', 'pleurisy'
    ],
    'cardiac': [
        'myocardial infarction', 'angina', 'arrhythmia',
        'cardiomyopathy', 'endocarditis', 'pericarditis'
    ],
    'neurological': [
        'stroke', 'seizure', 'migraine', 'multiple sclerosis',
        'Parkinson\'s disease', 'Alzheimer\'s disease'
    ],
    # ... more categories
}
```

---

### 2. Acronym Resolution
**Problem**: Medical abbreviations (DVT, COPD, MI) need expansion.

**Solution**: Implement acronym detection and expansion.

```python
MEDICAL_ACRONYMS = {
    'DVT': 'deep vein thrombosis',
    'MI': 'myocardial infarction',
    'COPD': 'chronic obstructive pulmonary disease',
    'CHF': 'congestive heart failure',
    'CVA': 'cerebrovascular accident',
    'TIA': 'transient ischemic attack',
    'GERD': 'gastroesophageal reflux disease',
    'UTI': 'urinary tract infection',
    'CAD': 'coronary artery disease',
}

def expand_acronyms(self, text):
    """Expand medical acronyms in text."""
    for acronym, expansion in MEDICAL_ACRONYMS.items():
        # Use word boundaries to avoid partial matches
        pattern = r'\b' + acronym + r'\b'
        text = re.sub(pattern, f"{acronym} ({expansion})", text)
    return text
```

---

### 3. Multi-word Entity Matching
**Enhancement**: Improve recognition of complex medical terms.

```python
# Add pattern-based matching for complex entities
from spacy.matcher import Matcher

def add_complex_patterns(self):
    """Add patterns for multi-word medical entities."""
    matcher = Matcher(self.nlp.vocab)
    
    # Pattern: [adjective] + [body part] + [condition]
    # Example: "bilateral lower extremity edema"
    pattern1 = [
        {"POS": "ADJ", "OP": "*"},  # Optional adjectives
        {"POS": "NOUN"},             # Body part
        {"LOWER": {"IN": ["pain", "swelling", "edema", "inflammation"]}}
    ]
    
    # Pattern: [severity] + [condition]
    # Example: "severe sepsis", "mild anemia"
    pattern2 = [
        {"LOWER": {"IN": ["severe", "mild", "moderate", "acute", "chronic"]}},
        {"POS": "NOUN"}
    ]
    
    matcher.add("COMPLEX_CONDITION", [pattern1, pattern2])
    return matcher
```

---

## Advanced Context Analysis

### 1. Temporal Information Extraction
**Goal**: Determine when conditions occurred.

```python
from medspacy.context import ConTextRule

def add_temporal_rules(self):
    """Add rules for temporal context detection."""
    temporal_rules = [
        ConTextRule("history of", "HISTORICAL", direction="forward"),
        ConTextRule("previous", "HISTORICAL", direction="forward"),
        ConTextRule("current", "CURRENT", direction="forward"),
        ConTextRule("acute", "CURRENT", direction="bidirectional"),
        ConTextRule("chronic", "HISTORICAL", direction="bidirectional"),
        ConTextRule("recent", "RECENT", direction="forward"),
    ]
    
    context = self.nlp.get_pipe("medspacy_context")
    context.add(temporal_rules)
```

**Output Enhancement**:
```python
{
    'condition': 'pneumonia',
    'sentiment': 'true',
    'temporal': 'current',  # or 'historical', 'recent'
    'onset': 'acute'
}
```

---

### 2. Severity Assessment
**Goal**: Classify condition severity.

```python
SEVERITY_INDICATORS = {
    'mild': ['mild', 'slight', 'minor', 'minimal'],
    'moderate': ['moderate', 'some', 'moderate'],
    'severe': ['severe', 'significant', 'marked', 'extensive', 'profound'],
    'critical': ['critical', 'life-threatening', 'emergent', 'acute']
}

def assess_severity(self, entity, doc):
    """Determine severity of a medical condition."""
    # Look for severity modifiers near the entity
    window = doc[max(0, entity.start-5):min(len(doc), entity.end+5)]
    
    for token in window:
        for severity, keywords in SEVERITY_INDICATORS.items():
            if token.text.lower() in keywords:
                return severity
    
    return 'unspecified'
```

---

### 3. Anatomical Location Extraction
**Goal**: Identify body parts/locations associated with conditions.

```python
def extract_anatomical_context(self, entity, doc):
    """Extract anatomical location for a condition."""
    # Common anatomical patterns
    anatomical_terms = {
        'cardiac': ['heart', 'cardiac', 'coronary'],
        'pulmonary': ['lung', 'pulmonary', 'respiratory'],
        'hepatic': ['liver', 'hepatic'],
        'renal': ['kidney', 'renal'],
        'cerebral': ['brain', 'cerebral', 'cranial'],
        'extremity': ['leg', 'arm', 'extremity']
    }
    
    window = doc[max(0, entity.start-10):entity.end]
    
    for category, terms in anatomical_terms.items():
        for token in window:
            if token.text.lower() in terms:
                return {
                    'location': token.text,
                    'category': category
                }
    
    return None
```

---

## Performance Optimizations

### 1. Batch Processing
**Goal**: Process multiple reports efficiently.

```python
def process_csv_batch(self, csv_path, batch_size=100):
    """Process CSV in batches for better performance."""
    df = pd.read_csv(csv_path)
    
    results = []
    for i in range(0, len(df), batch_size):
        batch = df.iloc[i:i+batch_size]
        
        # Process texts through pipeline in batch
        texts = (row['Findings'] + ' ' + row['Conclusions'] 
                for _, row in batch.iterrows())
        
        # Batch processing is much faster
        docs = list(self.nlp.pipe(texts, batch_size=batch_size))
        
        # Extract conditions from processed docs
        for doc, (idx, row) in zip(docs, batch.iterrows()):
            result = self._extract_from_doc(doc, row['RowID'])
            results.append(result)
    
    return pd.DataFrame(results)
```

---

### 2. Caching
**Goal**: Avoid reprocessing identical text.

```python
from functools import lru_cache
import hashlib

class CachedMedicalReportAnalyzer(MedicalReportAnalyzer):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.cache = {}
    
    def extract_conditions_cached(self, text):
        """Extract conditions with caching."""
        # Create hash of text
        text_hash = hashlib.md5(text.encode()).hexdigest()
        
        if text_hash in self.cache:
            return self.cache[text_hash]
        
        # Process if not cached
        result = self.extract_conditions(text)
        self.cache[text_hash] = result
        
        return result
```

---

### 3. Parallel Processing
**Goal**: Utilize multiple CPU cores.

```python
from multiprocessing import Pool
import multiprocessing as mp

def process_report_parallel(args):
    """Worker function for parallel processing."""
    row_id, findings, conclusions, model_name = args
    analyzer = MedicalReportAnalyzer(model_name)
    return analyzer.analyze_report(row_id, findings, conclusions)

def process_csv_parallel(self, csv_path, n_workers=None):
    """Process CSV using multiple processes."""
    if n_workers is None:
        n_workers = mp.cpu_count()
    
    df = pd.read_csv(csv_path)
    
    # Prepare arguments for workers
    args_list = [
        (row['RowID'], row['Findings'], row['Conclusions'], self.model_name)
        for _, row in df.iterrows()
    ]
    
    # Process in parallel
    with Pool(n_workers) as pool:
        results = pool.map(process_report_parallel, args_list)
    
    return results
```

---

## Integration and Deployment

### 1. RESTful API
**Goal**: Provide web service for real-time analysis.

```python
from flask import Flask, request, jsonify
from flask_cors import CORS

app = Flask(__name__)
CORS(app)

# Initialize analyzer once at startup
analyzer = MedicalReportAnalyzer()

@app.route('/analyze', methods=['POST'])
def analyze_report():
    """API endpoint to analyze a medical report."""
    data = request.json
    
    # Validate input
    if 'findings' not in data or 'conclusions' not in data:
        return jsonify({'error': 'Missing required fields'}), 400
    
    # Analyze report
    result = analyzer.analyze_report(
        row_id=data.get('row_id', 'api_request'),
        findings=data['findings'],
        conclusions=data['conclusions']
    )
    
    return jsonify(result)

@app.route('/health', methods=['GET'])
def health_check():
    """Health check endpoint."""
    return jsonify({'status': 'healthy', 'model': 'en_core_web_sm'})

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
```

**Usage**:
```bash
# Start server
python api_server.py

# Make request
curl -X POST http://localhost:5000/analyze \
  -H "Content-Type: application/json" \
  -d '{
    "row_id": "123",
    "findings": "Patient presents with fever and cough.",
    "conclusions": "Diagnosis: pneumonia"
  }'
```

---

### 2. Command-Line Interface Enhancements
**Goal**: More flexible CLI with options.

```python
import argparse

def parse_arguments():
    """Parse command line arguments."""
    parser = argparse.ArgumentParser(
        description='Analyze medical reports using MedSpacy'
    )
    
    parser.add_argument('input', help='Input CSV file path')
    parser.add_argument('-o', '--output', help='Output CSV file path')
    parser.add_argument('-m', '--model', default='en_core_web_sm',
                       help='spaCy model to use')
    parser.add_argument('-f', '--format', choices=['csv', 'json'],
                       default='csv', help='Output format')
    parser.add_argument('-v', '--verbose', action='store_true',
                       help='Verbose output')
    parser.add_argument('--confidence-threshold', type=float,
                       default=0.5, help='Minimum confidence score')
    parser.add_argument('--deduplicate', action='store_true',
                       help='Remove duplicate conditions')
    
    return parser.parse_args()

# Usage:
# python analyze_medical_reports.py input.csv -o output.json -f json --deduplicate
```

---

### 3. Database Integration
**Goal**: Store and query results in database.

```python
import sqlite3
from datetime import datetime

class DatabaseIntegration:
    def __init__(self, db_path='medical_reports.db'):
        self.conn = sqlite3.connect(db_path)
        self._create_tables()
    
    def _create_tables(self):
        """Create database schema."""
        cursor = self.conn.cursor()
        
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS reports (
                report_id TEXT PRIMARY KEY,
                findings TEXT,
                conclusions TEXT,
                analysis_date TIMESTAMP,
                total_conditions INTEGER
            )
        ''')
        
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS conditions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                report_id TEXT,
                condition_name TEXT,
                sentiment TEXT,
                confidence REAL,
                section TEXT,
                FOREIGN KEY (report_id) REFERENCES reports(report_id)
            )
        ''')
        
        self.conn.commit()
    
    def store_analysis(self, report_id, findings, conclusions, conditions):
        """Store analysis results in database."""
        cursor = self.conn.cursor()
        
        # Store report
        cursor.execute('''
            INSERT OR REPLACE INTO reports 
            VALUES (?, ?, ?, ?, ?)
        ''', (report_id, findings, conclusions, 
              datetime.now(), len(conditions)))
        
        # Store conditions
        for cond in conditions:
            cursor.execute('''
                INSERT INTO conditions 
                (report_id, condition_name, sentiment, confidence, section)
                VALUES (?, ?, ?, ?, ?)
            ''', (report_id, cond['condition'], cond['sentiment'],
                  cond.get('confidence', 1.0), cond.get('section', 'unknown')))
        
        self.conn.commit()
    
    def query_by_condition(self, condition_name):
        """Find all reports mentioning a specific condition."""
        cursor = self.conn.cursor()
        cursor.execute('''
            SELECT r.report_id, r.findings, c.sentiment
            FROM reports r
            JOIN conditions c ON r.report_id = c.report_id
            WHERE c.condition_name = ?
        ''', (condition_name,))
        
        return cursor.fetchall()
```

---

## Quality Assurance

### 1. Unit Testing
**Goal**: Ensure code reliability.

```python
import unittest

class TestMedicalReportAnalyzer(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        """Initialize analyzer once for all tests."""
        cls.analyzer = MedicalReportAnalyzer()
    
    def test_negation_detection(self):
        """Test that negated conditions are classified as false."""
        text = "Patient has no fever and no cough."
        conditions = self.analyzer.extract_conditions(text)
        
        fever_cond = [c for c in conditions if c['condition'] == 'fever']
        self.assertEqual(len(fever_cond), 1)
        self.assertEqual(fever_cond[0]['sentiment'], 'false')
    
    def test_uncertainty_detection(self):
        """Test that uncertain conditions are classified as indeterminate."""
        text = "Possible pneumonia. Likely bronchitis."
        conditions = self.analyzer.extract_conditions(text)
        
        for cond in conditions:
            self.assertEqual(cond['sentiment'], 'indeterminate')
    
    def test_affirmative_detection(self):
        """Test that affirmed conditions are classified as true."""
        text = "Patient diagnosed with diabetes mellitus."
        conditions = self.analyzer.extract_conditions(text)
        
        # Should find at least one affirmed condition
        affirmed = [c for c in conditions if c['sentiment'] == 'true']
        self.assertGreater(len(affirmed), 0)

if __name__ == '__main__':
    unittest.main()
```

---

### 2. Validation Against Gold Standard
**Goal**: Measure accuracy against expert annotations.

```python
def calculate_metrics(predictions, gold_standard):
    """Calculate precision, recall, F1 for condition extraction."""
    true_positives = 0
    false_positives = 0
    false_negatives = 0
    
    pred_set = set((c['condition'], c['sentiment']) for c in predictions)
    gold_set = set((c['condition'], c['sentiment']) for c in gold_standard)
    
    true_positives = len(pred_set & gold_set)
    false_positives = len(pred_set - gold_set)
    false_negatives = len(gold_set - pred_set)
    
    precision = true_positives / (true_positives + false_positives) if true_positives + false_positives > 0 else 0
    recall = true_positives / (true_positives + false_negatives) if true_positives + false_negatives > 0 else 0
    f1 = 2 * (precision * recall) / (precision + recall) if precision + recall > 0 else 0
    
    return {
        'precision': precision,
        'recall': recall,
        'f1': f1,
        'true_positives': true_positives,
        'false_positives': false_positives,
        'false_negatives': false_negatives
    }
```

---

### 3. Human-in-the-Loop Validation
**Goal**: Allow experts to review and correct results.

```python
def create_validation_interface(results):
    """Generate HTML interface for manual validation."""
    html = """
    <html>
    <head>
        <title>Medical Report Validation</title>
        <style>
            .condition { margin: 10px; padding: 10px; border: 1px solid #ccc; }
            .true { background-color: #d4edda; }
            .false { background-color: #f8d7da; }
            .indeterminate { background-color: #fff3cd; }
        </style>
    </head>
    <body>
    """
    
    for result in results:
        html += f"<h2>Report {result['row_id']}</h2>"
        html += f"<p><strong>Findings:</strong> {result['findings_text']}</p>"
        
        for cond in result['findings_conditions']:
            html += f"""
            <div class="condition {cond['sentiment']}">
                <strong>{cond['condition']}</strong>: {cond['sentiment']}
                <button onclick="correct('{cond['condition']}', 'true')">True</button>
                <button onclick="correct('{cond['condition']}', 'false')">False</button>
                <button onclick="correct('{cond['condition']}', 'indeterminate')">Indeterminate</button>
            </div>
            """
    
    html += "</body></html>"
    return html
```

---

## Summary of Priorities

### High Priority (Implement First)
1. ✅ Duplicate detection
2. ✅ Confidence scoring
3. ✅ JSON output format
4. ✅ Unit testing

### Medium Priority
5. ✅ Temporal analysis
6. ✅ Severity assessment
7. ✅ Batch processing
8. ✅ API development

### Low Priority (Future Work)
9. ✅ Database integration
10. ✅ UMLS integration
11. ✅ Parallel processing
12. ✅ Advanced visualization

---

## Getting Started with Improvements

To implement these recommendations:

1. **Choose a priority area** based on your needs
2. **Create a branch** for the feature
3. **Write tests first** (TDD approach)
4. **Implement incrementally**
5. **Validate results** against sample data
6. **Document changes** in code and README

## Questions?

For questions about these recommendations or help implementing them, please open an issue on the GitHub repository.
