"""
Unit tests for Medical Report Analyzer

This file contains basic tests to validate the core functionality
of the MedSpacy medical report analysis system.

To run tests:
    python test_analyzer.py
    
Or with pytest:
    pytest test_analyzer.py -v
"""

import unittest
import sys
from analyze_medical_reports import MedicalReportAnalyzer


class TestMedicalReportAnalyzer(unittest.TestCase):
    """Test cases for the MedicalReportAnalyzer class."""
    
    @classmethod
    def setUpClass(cls):
        """
        Initialize the analyzer once for all tests.
        
        This is done at the class level to avoid reloading the
        MedSpacy pipeline for each test, which would be slow.
        """
        print("\nInitializing MedSpacy analyzer for tests...")
        cls.analyzer = MedicalReportAnalyzer()
        print("Analyzer ready.\n")
    
    def test_initialization(self):
        """Test that the analyzer initializes successfully."""
        self.assertIsNotNone(self.analyzer.nlp)
        self.assertIn('medspacy_target_matcher', self.analyzer.nlp.pipe_names)
        self.assertIn('medspacy_context', self.analyzer.nlp.pipe_names)
    
    def test_negation_detection_simple(self):
        """Test that simple negated conditions are classified as false."""
        text = "Patient has no fever."
        conditions = self.analyzer.extract_conditions(text)
        
        # Find fever condition
        fever_conditions = [c for c in conditions if 'fever' in c['condition'].lower()]
        
        # Should find at least one fever condition
        self.assertGreater(len(fever_conditions), 0, 
                          "Should detect 'fever' in text")
        
        # Should be negated (false)
        fever = fever_conditions[0]
        self.assertEqual(fever['sentiment'], 'false',
                        f"'no fever' should be negated, got {fever['sentiment']}")
    
    def test_negation_detection_complex(self):
        """Test negation with more complex phrasing."""
        text = "No evidence of pneumonia. Patient denies chest pain."
        conditions = self.analyzer.extract_conditions(text)
        
        # Both conditions should be negated
        negated = [c for c in conditions if c['sentiment'] == 'false']
        self.assertGreater(len(negated), 0, 
                          "Should find at least one negated condition")
    
    def test_affirmative_detection(self):
        """Test that affirmed conditions are classified as true."""
        text = "Patient presents with fever and cough."
        conditions = self.analyzer.extract_conditions(text)
        
        # Should find affirmed conditions
        affirmed = [c for c in conditions if c['sentiment'] == 'true']
        self.assertGreater(len(affirmed), 0,
                          "Should find affirmed conditions")
        
        # Verify specific conditions
        condition_names = [c['condition'].lower() for c in affirmed]
        self.assertIn('fever', condition_names, 
                     "Should detect affirmed 'fever'")
    
    def test_uncertainty_detection(self):
        """Test that uncertain conditions are classified as indeterminate."""
        text = "Possible pneumonia. Suspicious for malignancy."
        conditions = self.analyzer.extract_conditions(text)
        
        # Should find uncertain conditions
        uncertain = [c for c in conditions if c['sentiment'] == 'indeterminate']
        self.assertGreater(len(uncertain), 0,
                          "Should find uncertain/indeterminate conditions")
    
    def test_empty_text(self):
        """Test handling of empty or None text."""
        # Empty string
        conditions = self.analyzer.extract_conditions("")
        self.assertEqual(len(conditions), 0, 
                        "Empty text should return no conditions")
        
        # None value
        conditions = self.analyzer.extract_conditions(None)
        self.assertEqual(len(conditions), 0,
                        "None text should return no conditions")
    
    def test_analyze_complete_report(self):
        """Test analyzing a complete report with findings and conclusions."""
        findings = "Patient presents with fever, cough, and shortness of breath."
        conclusions = "Diagnosis: Pneumonia. Recommend antibiotics."
        
        result = self.analyzer.analyze_report("TEST_001", findings, conclusions)
        
        # Verify structure
        self.assertIn('row_id', result)
        self.assertIn('findings_conditions', result)
        self.assertIn('conclusions_conditions', result)
        self.assertIn('total_conditions', result)
        
        # Should find conditions
        self.assertGreater(result['total_conditions'], 0,
                          "Should find conditions in the report")
    
    def test_condition_attributes(self):
        """Test that extracted conditions have required attributes."""
        text = "Patient has pneumonia."
        conditions = self.analyzer.extract_conditions(text)
        
        # Should find at least one condition
        self.assertGreater(len(conditions), 0, "Should find conditions")
        
        # Check required attributes
        condition = conditions[0]
        required_keys = ['condition', 'sentiment', 'reason', 
                        'is_negated', 'is_uncertain']
        
        for key in required_keys:
            self.assertIn(key, condition,
                         f"Condition should have '{key}' attribute")
    
    def test_multiple_conditions_same_text(self):
        """Test extraction of multiple conditions from the same text."""
        text = "Patient has fever, cough, pneumonia, and dyspnea."
        conditions = self.analyzer.extract_conditions(text)
        
        # Should find multiple conditions
        self.assertGreater(len(conditions), 1,
                          "Should find multiple conditions in text")
    
    def test_medical_pattern_matching(self):
        """Test that custom medical patterns are recognized."""
        # Test various condition types
        test_cases = [
            ("Patient has pneumonia", "pneumonia"),
            ("Diagnosis: COPD", "copd"),
            ("Evidence of deep vein thrombosis", "deep vein thrombosis"),
            ("Patient presents with anemia", "anemia"),
        ]
        
        for text, expected_condition in test_cases:
            conditions = self.analyzer.extract_conditions(text)
            condition_names = [c['condition'].lower() for c in conditions]
            
            # Check if expected condition is found
            found = any(expected_condition in name for name in condition_names)
            self.assertTrue(found,
                           f"Should detect '{expected_condition}' in '{text}'")
    
    def test_format_condition_output(self):
        """Test the condition output formatting."""
        condition = {
            'condition': 'pneumonia',
            'sentiment': 'true',
            'reason': 'affirmed'
        }
        
        formatted = self.analyzer.format_condition_output(condition)
        
        # Check format
        self.assertIn('pneumonia', formatted)
        self.assertIn('true', formatted)
        self.assertIn('affirmed', formatted)
    
    def test_real_world_example_1(self):
        """Test with a real-world pneumonia report."""
        findings = ("Patient presents with fever, cough, and shortness of breath. "
                   "Chest X-ray shows bilateral infiltrates consistent with pneumonia. "
                   "No pleural effusion noted.")
        
        conditions = self.analyzer.extract_conditions(findings)
        
        # Should find pneumonia as affirmed
        pneumonia = [c for c in conditions 
                    if 'pneumonia' in c['condition'].lower() 
                    and c['sentiment'] == 'true']
        self.assertGreater(len(pneumonia), 0, 
                          "Should find affirmed pneumonia")
        
        # Should find pleural effusion as negated
        effusion = [c for c in conditions 
                   if 'effusion' in c['condition'].lower() 
                   and c['sentiment'] == 'false']
        self.assertGreater(len(effusion), 0,
                          "Should find negated pleural effusion")
    
    def test_real_world_example_2(self):
        """Test with a rule-out myocardial infarction report."""
        findings = ("Patient denies chest pain. EKG shows normal sinus rhythm. "
                   "No signs of acute myocardial infarction.")
        
        conditions = self.analyzer.extract_conditions(findings)
        
        # Should find negated conditions
        negated = [c for c in conditions if c['sentiment'] == 'false']
        self.assertGreater(len(negated), 0,
                          "Should find negated conditions in rule-out case")
    
    def test_real_world_example_3(self):
        """Test with an uncertain diagnosis report."""
        findings = ("MRI shows multiple lesions. Pattern suggestive of "
                   "demyelinating disease, possibly multiple sclerosis.")
        
        conditions = self.analyzer.extract_conditions(findings)
        
        # Should find uncertain conditions
        uncertain = [c for c in conditions 
                    if c['sentiment'] == 'indeterminate']
        self.assertGreater(len(uncertain), 0,
                          "Should find uncertain/indeterminate conditions")


class TestCSVProcessing(unittest.TestCase):
    """Test CSV file processing functionality."""
    
    @classmethod
    def setUpClass(cls):
        """Initialize analyzer for CSV tests."""
        cls.analyzer = MedicalReportAnalyzer()
    
    def test_sample_csv_exists(self):
        """Test that the sample CSV file exists."""
        import os
        self.assertTrue(os.path.exists('sample_medical_reports.csv'),
                       "Sample CSV file should exist")
    
    def test_sample_csv_format(self):
        """Test that the sample CSV has required columns."""
        import pandas as pd
        
        df = pd.read_csv('sample_medical_reports.csv')
        
        required_columns = ['RowID', 'Findings', 'Conclusions']
        for col in required_columns:
            self.assertIn(col, df.columns,
                         f"CSV should have '{col}' column")
        
        # Should have 10 sample reports
        self.assertEqual(len(df), 10,
                        "Sample CSV should have 10 reports")


def run_tests():
    """Run all tests and print results."""
    print("="*80)
    print("RUNNING MEDICAL REPORT ANALYZER TESTS")
    print("="*80)
    
    # Create test suite
    loader = unittest.TestLoader()
    suite = unittest.TestSuite()
    
    # Add all test cases
    suite.addTests(loader.loadTestsFromTestCase(TestMedicalReportAnalyzer))
    suite.addTests(loader.loadTestsFromTestCase(TestCSVProcessing))
    
    # Run tests with verbose output
    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(suite)
    
    # Print summary
    print("\n" + "="*80)
    print("TEST SUMMARY")
    print("="*80)
    print(f"Tests run: {result.testsRun}")
    print(f"Successes: {result.testsRun - len(result.failures) - len(result.errors)}")
    print(f"Failures: {len(result.failures)}")
    print(f"Errors: {len(result.errors)}")
    print("="*80)
    
    # Return exit code
    return 0 if result.wasSuccessful() else 1


if __name__ == '__main__':
    sys.exit(run_tests())
