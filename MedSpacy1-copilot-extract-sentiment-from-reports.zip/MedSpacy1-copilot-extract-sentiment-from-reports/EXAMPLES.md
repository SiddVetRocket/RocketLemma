# Usage Examples

This document provides practical examples of using the MedSpacy Medical Report Analysis system.

## Table of Contents
1. [Basic Usage](#basic-usage)
2. [Understanding the Output](#understanding-the-output)
3. [Real-World Examples](#real-world-examples)
4. [Error Handling](#error-handling)
5. [Tips and Best Practices](#tips-and-best-practices)

---

## Basic Usage

### Example 1: Analyzing the Sample Data

The simplest way to get started is to run the script with the provided sample data:

```bash
python analyze_medical_reports.py
```

This will:
- Read `sample_medical_reports.csv`
- Analyze all 10 reports
- Generate `analysis_results.csv`
- Print a summary to the console

**Expected Output**:
```
================================================================================
MEDICAL REPORT ANALYSIS USING MEDSPACY
================================================================================

Input file: sample_medical_reports.csv
Output file: analysis_results.csv
...
Total Reports Analyzed: 10
Total Conditions Found: 57
Average Conditions per Report: 5.70
```

---

### Example 2: Custom Input/Output Files

```bash
python analyze_medical_reports.py my_reports.csv my_results.csv
```

This allows you to specify:
- Custom input CSV file: `my_reports.csv`
- Custom output CSV file: `my_results.csv`

---

### Example 3: Using in Python Code

```python
from analyze_medical_reports import MedicalReportAnalyzer

# Initialize the analyzer
analyzer = MedicalReportAnalyzer()

# Analyze a single report
result = analyzer.analyze_report(
    row_id="PATIENT_001",
    findings="Patient presents with fever, cough, and dyspnea. "
             "Chest X-ray shows bilateral infiltrates.",
    conclusions="Diagnosis: Community-acquired pneumonia. "
                "Recommend antibiotics and monitoring."
)

# Access the results
print(f"Found {result['total_conditions']} conditions")
for condition in result['findings_conditions']:
    print(f"  - {condition['condition']}: {condition['sentiment']}")
```

**Output**:
```
Found 5 conditions
  - fever: true
  - cough: true
  - dyspnea: true
  - infiltrates: true
  - pneumonia: true
```

---

## Understanding the Output

### CSV Output Format

The output CSV contains these key columns:

| Column | Description | Example |
|--------|-------------|---------|
| `RowID` | Original report identifier | "1" |
| `Findings` | Original findings text | "Patient presents with..." |
| `Conclusions` | Original conclusions text | "Diagnosis: pneumonia..." |
| `Conditions_Found` | Total number of conditions | 7 |
| `Conditions_List` | Human-readable summary | "fever: true \| cough: true \| pneumonia: true" |
| `Condition_1` | First condition name | "fever" |
| `Condition_1_Sentiment` | Sentiment for first condition | "true" |
| `Condition_1_Reason` | Reason for classification | "affirmed" |

---

### Sentiment Values

The system classifies each condition into one of three categories:

#### ✅ TRUE (Affirmed)
Condition is present and confirmed.

**Examples**:
- "Patient **has** pneumonia" → pneumonia: **true**
- "Diagnosis: **diabetes mellitus**" → diabetes mellitus: **true**
- "Evidence of **pulmonary edema**" → pulmonary edema: **true**

#### ❌ FALSE (Negated)
Condition is explicitly ruled out or absent.

**Examples**:
- "**No evidence of** pneumonia" → pneumonia: **false**
- "Patient **denies** chest pain" → chest pain: **false**
- "**Without** signs of infection" → infection: **false**

#### ⚠️ INDETERMINATE (Uncertain)
Condition is possible but not confirmed.

**Examples**:
- "**Possible** pneumonia" → pneumonia: **indeterminate**
- "**Suspicious for** malignancy" → malignancy: **indeterminate**
- "**Cannot exclude** DVT" → DVT: **indeterminate**

---

## Real-World Examples

### Example 1: Pneumonia Case

**Input**:
```csv
RowID,Findings,Conclusions
101,"Patient presents with fever, productive cough, and shortness of breath. Chest X-ray shows right lower lobe infiltrate consistent with pneumonia. No pleural effusion noted.","Diagnosis: Community-acquired pneumonia. Start antibiotics."
```

**Analysis Result**:
```
Report 101:
  Conditions:
    - fever: true (affirmed)
    - cough: true (affirmed)
    - shortness of breath: true (affirmed)
    - infiltrate: true (affirmed)
    - pneumonia: true (affirmed)
    - pleural effusion: false (negated)
```

**Interpretation**:
- ✅ Patient **has** fever, cough, shortness of breath
- ✅ X-ray confirms pneumonia
- ❌ Pleural effusion is explicitly ruled out

---

### Example 2: Rule-Out Case

**Input**:
```csv
RowID,Findings,Conclusions
102,"Patient denies chest pain. EKG shows normal sinus rhythm. Troponin levels within normal limits. No signs of acute myocardial infarction.","Rule out myocardial infarction successful. Chest pain likely musculoskeletal."
```

**Analysis Result**:
```
Report 102:
  Conditions:
    - chest pain: false (negated)
    - myocardial infarction: false (negated)
    - chest pain: true (affirmed) [from Conclusions]
```

**Interpretation**:
- ❌ Patient **denies** chest pain in Findings
- ❌ Myocardial infarction **ruled out**
- ✅ Alternative diagnosis (musculoskeletal pain) mentioned in Conclusions

**Note**: This example shows how the same condition can appear with different sentiments in different sections.

---

### Example 3: Uncertain Diagnosis

**Input**:
```csv
RowID,Findings,Conclusions
103,"MRI of brain shows multiple hyperintense lesions in white matter. Pattern suggestive of demyelinating disease, possibly multiple sclerosis. No mass effect.","Findings suspicious for multiple sclerosis. Recommend neurology referral."
```

**Analysis Result**:
```
Report 103:
  Conditions:
    - lesions: true (affirmed)
    - demyelinating disease: indeterminate (uncertain)
    - multiple sclerosis: indeterminate (uncertain)
    - mass: false (negated)
```

**Interpretation**:
- ✅ Lesions are **confirmed** on MRI
- ⚠️ Demyelinating disease is **suggested** but not confirmed
- ⚠️ Multiple sclerosis is **possible** but needs further workup
- ❌ Mass effect is **absent**

---

### Example 4: Normal Report

**Input**:
```csv
RowID,Findings,Conclusions
104,"CT scan of abdomen reveals no acute pathology. Liver and kidneys appear normal. No masses or lesions identified.","Normal abdominal CT. No acute findings."
```

**Analysis Result**:
```
Report 104:
  Conditions:
    - pathology: false (negated)
    - normal: true (affirmed)
    - masses: false (negated)
    - lesions: false (negated)
    - acute findings: false (negated)
```

**Interpretation**:
- ❌ No pathology, masses, or lesions found
- ✅ Organs appear **normal**
- ❌ No **acute findings** requiring intervention

---

### Example 5: Complex Multi-Condition Report

**Input**:
```csv
RowID,Findings,Conclusions
105,"Patient with history of COPD presents with worsening dyspnea. Chest X-ray shows hyperinflation but no acute infiltrates. Possible superimposed pneumonia cannot be excluded. No pleural effusion.","COPD exacerbation likely. Consider antibiotics if pneumonia develops."
```

**Analysis Result**:
```
Report 105:
  Conditions:
    - COPD: true (affirmed)
    - dyspnea: true (affirmed)
    - infiltrates: false (negated)
    - pneumonia: indeterminate (uncertain)
    - pleural effusion: false (negated)
```

**Interpretation**:
- ✅ Patient **has** known COPD
- ✅ Currently experiencing **dyspnea**
- ❌ No acute infiltrates on X-ray
- ⚠️ Pneumonia **cannot be excluded** (uncertain)
- ❌ No pleural effusion

---

## Error Handling

### Missing Required Columns

**Error**:
```
Error: CSV missing required columns: ['Conclusions']
Available columns: ['RowID', 'Findings', 'Notes']
```

**Solution**: Ensure your CSV has exactly these columns:
- `RowID`
- `Findings`
- `Conclusions`

---

### File Not Found

**Error**:
```
Error: File not found: my_reports.csv
```

**Solution**: Check the file path and ensure the file exists:
```bash
ls -la my_reports.csv
```

---

### Model Not Installed

**Error**:
```
Model 'en_core_web_sm' not found. Please install it:
python -m spacy download en_core_web_sm
```

**Solution**: Install the required spaCy model:
```bash
python -m spacy download en_core_web_sm
```

---

## Tips and Best Practices

### 1. Input Text Quality

**Good Practice**: Provide clear, well-formatted text
```
✅ "Patient presents with fever, cough, and dyspnea. Chest X-ray shows infiltrates."
```

**Avoid**: Excessive abbreviations or poor formatting
```
❌ "Pt w/ fvr, cgh. CXR: inf."
```

**Why**: The NLP model works best with complete sentences and standard medical terminology.

---

### 2. Handling Empty Sections

If a report has no Findings or Conclusions, use empty strings or placeholders:

```csv
RowID,Findings,Conclusions
201,"","Final diagnosis: Normal examination. No pathology identified."
202,"Physical examination unremarkable.",""
```

The system will handle empty sections gracefully.

---

### 3. Reviewing Results

Always review the results, especially for:

1. **Negated conditions**: Verify they are truly absent
   - "No evidence of pneumonia" → pneumonia: false ✓

2. **Uncertain conditions**: Consider need for follow-up
   - "Possible DVT" → DVT: indeterminate → May need ultrasound

3. **Duplicate conditions**: Same condition in Findings and Conclusions
   - Check if sentiment changed between sections

---

### 4. Working with Large Datasets

For processing hundreds or thousands of reports:

```python
import pandas as pd
from analyze_medical_reports import MedicalReportAnalyzer

# Process in batches
analyzer = MedicalReportAnalyzer()
batch_size = 100

df = pd.read_csv('large_dataset.csv')
results = []

for i in range(0, len(df), batch_size):
    batch = df.iloc[i:i+batch_size]
    print(f"Processing batch {i//batch_size + 1}...")
    
    for _, row in batch.iterrows():
        result = analyzer.analyze_report(
            row['RowID'], 
            row['Findings'], 
            row['Conclusions']
        )
        results.append(result)

# Save results
output_df = pd.DataFrame(results)
output_df.to_csv('large_results.csv', index=False)
```

---

### 5. Integrating with Existing Systems

**Example: Load from database**
```python
import sqlite3
from analyze_medical_reports import MedicalReportAnalyzer

# Connect to database
conn = sqlite3.connect('medical_records.db')
cursor = conn.cursor()

# Fetch reports
cursor.execute("""
    SELECT patient_id, findings, conclusions 
    FROM reports 
    WHERE status = 'pending_analysis'
""")

analyzer = MedicalReportAnalyzer()

# Analyze each report
for patient_id, findings, conclusions in cursor.fetchall():
    result = analyzer.analyze_report(patient_id, findings, conclusions)
    
    # Store results back to database
    cursor.execute("""
        INSERT INTO analysis_results 
        (patient_id, conditions_json, analysis_date)
        VALUES (?, ?, datetime('now'))
    """, (patient_id, json.dumps(result)))

conn.commit()
```

---

### 6. Custom Filtering

**Example: Show only affirmed conditions**
```python
result = analyzer.analyze_report(row_id, findings, conclusions)

affirmed_conditions = [
    c for c in result['findings_conditions'] + result['conclusions_conditions']
    if c['sentiment'] == 'true'
]

print("Confirmed conditions:")
for cond in affirmed_conditions:
    print(f"  - {cond['condition']}")
```

**Example: Filter by section**
```python
# Get only conditions from Findings
findings_only = result['findings_conditions']

# Get only conditions from Conclusions
conclusions_only = result['conclusions_conditions']
```

---

## Advanced Usage

### Custom Medical Patterns

You can extend the system with additional medical terms:

```python
from medspacy.ner import TargetRule

# Add custom patterns
analyzer = MedicalReportAnalyzer()
target_matcher = analyzer.nlp.get_pipe("medspacy_target_matcher")

custom_patterns = [
    TargetRule("COVID-19", "CONDITION"),
    TargetRule("long COVID", "CONDITION"),
    TargetRule("post-viral syndrome", "CONDITION"),
]

target_matcher.add(custom_patterns)

# Now analyze with extended patterns
result = analyzer.analyze_report(...)
```

---

## Sample Workflow

Here's a complete workflow for analyzing medical reports:

```bash
# 1. Prepare your CSV file
# Ensure it has columns: RowID, Findings, Conclusions

# 2. Run the analysis
python analyze_medical_reports.py my_reports.csv results.csv

# 3. Review the summary output
# Check total conditions found and any errors

# 4. Open the results CSV
# Use Excel, LibreOffice, or pandas to explore results

# 5. Filter for specific conditions
# Example: Find all reports mentioning "pneumonia"
grep -i "pneumonia" results.csv

# 6. Generate statistics
# Count affirmed vs negated conditions
```

---

## Getting Help

If you encounter issues:

1. Check the [README.md](README.md) for setup instructions
2. Review [RECOMMENDATIONS.md](RECOMMENDATIONS.md) for advanced features
3. Open an issue on GitHub with:
   - Your input CSV format
   - Error messages
   - Expected vs. actual output

---

## Next Steps

After mastering basic usage:

1. Explore the [RECOMMENDATIONS.md](RECOMMENDATIONS.md) document for enhancement ideas
2. Experiment with different medical terminology
3. Consider implementing confidence scoring for production use
4. Set up automated batch processing for your workflow
