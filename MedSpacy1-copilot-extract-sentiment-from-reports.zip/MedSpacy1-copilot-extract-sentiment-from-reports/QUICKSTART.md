# Quick Start Guide

Get up and running with MedSpacy Medical Report Analysis in 5 minutes.

## Prerequisites

- Python 3.8 or higher
- pip package manager
- Basic knowledge of command line

## Installation (3 steps)

### 1. Clone the repository
```bash
git clone https://github.com/Vet-Rocket/MedSpacy1.git
cd MedSpacy1
```

### 2. Install dependencies
```bash
pip install -r requirements.txt
```

This installs:
- MedSpacy (clinical NLP library)
- spaCy (base NLP library)
- pandas (CSV processing)

### 3. Download language model
```bash
python -m spacy download en_core_web_sm
```

This downloads a ~20MB English language model.

## Your First Analysis

Run the script with the included sample data:

```bash
python analyze_medical_reports.py
```

**What happens:**
1. Loads 10 sample medical reports
2. Analyzes Findings and Conclusions
3. Extracts medical conditions
4. Classifies each as: true, false, or indeterminate
5. Saves results to `analysis_results.csv`
6. Prints summary to console

**Expected output:**
```
================================================================================
MEDICAL REPORT ANALYSIS USING MEDSPACY
================================================================================

Input file: sample_medical_reports.csv
Output file: analysis_results.csv
...
Total Reports Analyzed: 10
Total Conditions Found: 57
Average Conditions per Report: 5.70
```

## View the Results

### Option 1: Command line
```bash
# View first few lines
head -n 3 analysis_results.csv

# Search for specific condition
grep "pneumonia" analysis_results.csv
```

### Option 2: Spreadsheet
Open `analysis_results.csv` in Excel, Google Sheets, or LibreOffice Calc

### Option 3: Python
```python
import pandas as pd

df = pd.read_csv('analysis_results.csv')
print(df[['RowID', 'Conditions_Found', 'Conditions_List']].head())
```

## Analyze Your Own Data

### Step 1: Prepare your CSV file

Create a CSV with three columns:

```csv
RowID,Findings,Conclusions
001,"Patient has fever and cough","Diagnosis: Upper respiratory infection"
002,"No acute findings","Normal examination"
```

**Requirements:**
- Must have columns: `RowID`, `Findings`, `Conclusions`
- UTF-8 encoding
- CSV format

### Step 2: Run analysis

```bash
python analyze_medical_reports.py your_data.csv your_results.csv
```

### Step 3: Review results

Open `your_results.csv` and check:
- `Conditions_Found`: Number of conditions per report
- `Conditions_List`: Human-readable summary
- Individual condition columns: Detailed breakdowns

## Understanding the Output

Each condition is classified:

| Sentiment | Meaning | Example |
|-----------|---------|---------|
| **true** | Condition is present | "Patient has pneumonia" |
| **false** | Condition is absent | "No fever detected" |
| **indeterminate** | Condition is uncertain | "Possible pneumonia" |

## Quick Examples

### Example 1: Affirmed Condition
```
Input: "Patient diagnosed with pneumonia."
Output: pneumonia: true (affirmed)
```

### Example 2: Negated Condition
```
Input: "No evidence of pneumonia."
Output: pneumonia: false (negated)
```

### Example 3: Uncertain Condition
```
Input: "Possible pneumonia."
Output: pneumonia: indeterminate (uncertain)
```

## Running Tests

Verify everything works:

```bash
python test_analyzer.py
```

Should see:
```
Ran 16 tests in 1.058s
OK
```

## Common Issues

### Issue: "Model not found"
```bash
python -m spacy download en_core_web_sm
```

### Issue: "Module not found: medspacy"
```bash
pip install -r requirements.txt
```

### Issue: "CSV missing columns"
Ensure your CSV has exactly: `RowID`, `Findings`, `Conclusions`

## Next Steps

1. **Learn more**: Read [README.md](README.md) for detailed documentation
2. **See examples**: Check [EXAMPLES.md](EXAMPLES.md) for usage patterns
3. **Explore improvements**: Review [RECOMMENDATIONS.md](RECOMMENDATIONS.md) for enhancements
4. **Run tests**: Execute `python test_analyzer.py` to validate setup

## Getting Help

- **Documentation**: See README.md, EXAMPLES.md, RECOMMENDATIONS.md
- **Issues**: Open a GitHub issue with details
- **Questions**: Provide sample input/output for troubleshooting

## Summary

You've learned how to:
- ✅ Install MedSpacy and dependencies
- ✅ Run analysis on sample data
- ✅ Understand the output format
- ✅ Analyze your own medical reports
- ✅ Troubleshoot common issues

**Ready to analyze medical reports!** 🎉
